# OpenStack ocata installation script on Ubuntu 16.04.2 
# by kasidit chanchio
# vasabilab, dept of computer science, 
# Thammasat University, Thailand
#
# Copyright 2017  Kasidit Chanchio
#
#!/bin/bash -x
#
#
intype=vasabi-1234install_type4321-ibasav
full=full
#
# neutron
ssh -t openstack@controller sudo /bin/bash -x ./OPSInstaller/controller/exe-stage21-SUDO-neutron-database.sh | tee log/s21-controller.log
ssh -t openstack@controller /bin/bash -x ./OPSInstaller/controller/exe-stage22-USER-neutron-endpoints.sh | tee log/s22-controller.log
ssh -t openstack@controller sudo /bin/bash -x ./OPSInstaller/controller/exe-stage23-SUDO-neutron.sh | tee log/s23-controller.log
sleep 5
ssh -t openstack@controller /bin/bash -x ./OPSInstaller/controller/exe-stage24-USER-verify-neutron.sh | tee log/s24-controller.log
sleep 5
ssh -t openstack@network sudo /bin/bash -x ./OPSInstaller/network/exe-stage25-SUDO-network-neutron.sh | tee log/s25-network.log
sleep 5
ssh -t openstack@controller sudo /bin/bash -x ./OPSInstaller/controller/exe-stage26-SUDO-reconfig-neutron-nova.sh | tee log/s26-controller.log
sleep 5
ssh -t openstack@network sudo /bin/bash -x ./OPSInstaller/network/exe-stage27-SUDO-ovs-service.sh | tee log/s27-network.log
sleep 5
ssh -t openstack@controller /bin/bash -x ./OPSInstaller/controller/exe-stage28-USER-verify-neutron2.sh | tee log/s28-controller.log
sleep 5
ssh -t openstack@compute sudo /bin/bash -x ./OPSInstaller/compute/exe-stage29-SUDO-compute-neutron.sh | tee log/s29-compute.log
sleep 5
if [ "$intype" == "$full" ]
then
ssh -t openstack@compute1 sudo /bin/bash -x ./OPSInstaller/compute1/exe-stage29-SUDO-compute-neutron.sh | tee log/s29-compute.log
fi
sleep 5
ssh -t openstack@controller /bin/bash -x ./OPSInstaller/controller/exe-stage30-USER-verify-neutron3.sh | tee log/s30-controller.log
printf "\nCreate initial networks to test the clasic OVS neutron installation.\n If you want to use neutron with classic openvswitch,\npress any key to continue. The initial network will be created.\n Otherwise, press Ctrl C to stop this script and run \n./OS-installer-08-horizon.sh before running ./OS-installer-09... and ./OS-installer-10....\n"
read varkey
ssh -t openstack@controller /bin/bash -x ./OPSInstaller/controller/exe-stage31-USER-initial-network.sh | tee log/s31-controller.log
printf "\nnext run ./OS-installer-08-horizon.sh and finish the classic OVS installation.\n"
