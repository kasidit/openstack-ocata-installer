echo "adjust sudoer file"
sudo ./files/adjustsudoer.sh
