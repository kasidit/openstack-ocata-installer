sed -i "s/localrepo/th.archive.ubuntu.com/g" local-sources.list
sed -i "s/localsecurityrepo/security.ubuntu.com/g" local-sources.list

