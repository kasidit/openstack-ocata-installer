cp /etc/sudoers /tmp/sudoers.save
echo "openstack ALL=NOPASSWD: ALL" >> /etc/sudoers

